/*
 * SyncSema.h
 *
 *  Created on: Apr 2, 2021
 *      Author: hoang
 */

#ifndef INC_SYNCSEMA_H_
#define INC_SYNCSEMA_H_

void InitEFSema(void);

void SetEFSema(void);

void WaitEFSema(void);



#endif /* INC_SYNCSEMA_H_ */
